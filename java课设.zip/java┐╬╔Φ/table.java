package java课设;

public class table {
    public void showtable(){
        System.out.println("   生活百宝箱");
        System.out.println("1，ip归属地查询");
        System.out.println("2，身份证归属地查询");
        System.out.println("3，手机号码归属地查询");
        System.out.println("4，退出");
        System.out.println("请输入你想要服务的编号:");
    }
}
