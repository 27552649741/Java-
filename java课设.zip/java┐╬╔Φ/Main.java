package java课设;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        while (true){
            int flag = 0;
            table table1 = new table();
            table1.showtable();
            int num = sc.nextInt();
            switch (num)
            {
                case 1:
                    System.out.println("请输入ip地址：");
                    String ip = sc.next();
                    String url1 = "http://ipchaxun.com/"+ip+"/";
                    Document doc1 =  Jsoup.connect(url1).get();
                    Elements els1 = doc1.getElementsByClass("value");
                    String str1 = els1.text();
                    break;

                case 2:
                    System.out.println("请输入身份证号：");
                    String IDnumber = sc.next();
                    try {
                        System.out.print(IdCardService.getIdCardDetail(IDnumber));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    break;
                case 3:
                    System.out.println("请输入手机号：");
                    String mobile = sc.next();
                    String url5 = "http://www.ip138.com/mobile.asp?action=mobile&mobile=%s";
                    url5 = String.format(url5, mobile);
                    Document doc5 =  Jsoup.connect(url5).get();
                    Elements els5 = doc5.getElementsByClass("table");
                    String str5 = els5.get(0).text();
                    System.out.println(""+str5.substring(49,56));
                    break;

                case 4: flag = 1;break;
                default:break;
            }
            if(flag==1)
                break;
            System.out.println("请选择");
            System.out.println("1，继续服务");
            System.out.println("2，退出服务");
            int flag1 = sc.nextInt();
            switch(flag1){
                case 1:break;
                case 2:flag=1;break;
            }
            if(flag==1)
                break;
        }

    }
}
